import 'package:get/get.dart';
import 'package:camera/camera.dart';
import 'package:google_ml_kit/google_ml_kit.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';

class HomeController extends GetxController {
  RxString selectedImagePath = ''.obs;
  RxString extractedBarcode = ''.obs;
  RxBool isCameraInitialized = false.obs;
  RxInt tabIndex = 0.obs;
  RxList<String> favCompaniesName = <String>[].obs;
  RxList<String> favCompaniesConfidence = <String>[].obs;
  RxList<String> favCompaniesOutcome = <String>[].obs;
  var companyName = ''.obs;
  var sentiment = ''.obs;
  var percentageP = 0.obs;
  var percentageI = 0.obs;
  var percentageN = 0.obs;
  var confidence = 0.0.obs;
  var titlesAndUrls = <Map<String, String>>[].obs;
  var favoriteIcon = Rx<IconData>(Icons.favorite_border);

  late CameraController cameraController;

  @override
  void onInit() {
    super.onInit();
    initializeCamera();
  }

  Future<void> initializeCamera() async {
    final cameras = await availableCameras();
    final firstCamera = cameras.first;

    cameraController = CameraController(firstCamera, ResolutionPreset.medium);
    await cameraController.initialize();
    isCameraInitialized.value = true;
  }

  Future<void> takePhoto() async {
    if (!isCameraInitialized.value) {
      Get.snackbar("Error", "Camera not initialized", backgroundColor: Colors.red);
      return;
    }
    final XFile? photo = await cameraController.takePicture();
    if (photo != null) {
      selectedImagePath.value = photo.path;
      isCameraInitialized.value = false; // Stop camera preview
      // Call your method to recognize text or process the photo
      await recognizedText(selectedImagePath.value);
    }
  }

  Future<void> recognizedText(String pickedImage) async {
    if (pickedImage.isEmpty) {
      Get.snackbar("Error", "Image is not selected", backgroundColor: Colors.red);
    } else {
      extractedBarcode.value = '';
      var barCodeScanner = GoogleMlKit.vision.barcodeScanner();
      final visionImage = InputImage.fromFilePath(pickedImage);

      try {
        var barcodeText = await barCodeScanner.processImage(visionImage);
        for (Barcode barcode in barcodeText) {
          extractedBarcode.value = barcode.displayValue!;
          print('Barcode found: ${barcode.displayValue}');
        }
      } catch (e) {
        Get.snackbar("Error", e.toString(), backgroundColor: Colors.red);
      }
    }
  }

  Future<void> fetchData(String barcodeNumber) async {
    try {
      String link = 'https://hello-world-2-5okhtgcega-uc.a.run.app/companyname?barcode=' + barcodeNumber;
      print(link);
      final response = await http.get(Uri.parse(link));
      if (response.statusCode == 200) {
        // If the server returns a 200 OK response, parse the value from the response body
        // Parsing the JSON string
        String jsonString = response.body;
        Map<String, dynamic> jsonMap = jsonDecode(jsonString);

        // Assign values to the reactive variables
        titlesAndUrls = <Map<String, String>>[].obs;
        companyName.value = jsonMap['Company Name'];
        sentiment.value = jsonMap['Sentiment'];
        percentageP.value = (jsonMap['Percentage']['P'] as num).round();
        percentageI.value = (jsonMap['Percentage']['I'] as num).round();
        percentageN.value = (jsonMap['Percentage']['N'] as num).round();
        confidence.value = jsonMap['Confidence'];
        titlesAndUrls.assignAll([
          {
            'Title': jsonMap['Title_1'],
            'URL': jsonMap['URL_1'],
          },
          {
            'Title': jsonMap['Title_2'],
            'URL': jsonMap['URL_2'],
          },
          {
            'Title': jsonMap['Title_3'],
            'URL': jsonMap['URL_3'],
          },
          {
            'Title': jsonMap['Title_4'],
            'URL': jsonMap['URL_4'],
          },
          {
            'Title': jsonMap['Title_5'],
            'URL': jsonMap['URL_5'],
          },
          {
            'Title': jsonMap['Title_6'],
            'URL': jsonMap['URL_6'],
          },
          {
            'Title': jsonMap['Title_7'],
            'URL': jsonMap['URL_7'],
          },
          {
            'Title': jsonMap['Title_8'],
            'URL': jsonMap['URL_8'],
          },
          {
            'Title': jsonMap['Title_9'],
            'URL': jsonMap['URL_9'],
          },
          {
            'Title': jsonMap['Title_10'],
            'URL': jsonMap['URL_10'],
          },

        ]);

      print(titlesAndUrls);
      } else {
        // If the server did not return a 200 OK response, handle the error accordingly
        throw Exception('Failed to load data: ' + response.statusCode.toString());
      }
    } catch (error) {
      // Handle any exceptions that may occur during the HTTP request
      print("Error: $error");
    }
  }

  void changeTabIndex(int index) {
    tabIndex.value = index;
  }

  @override
  void onClose() {
    if (isCameraInitialized.value) {
      cameraController.dispose();
    }
    super.onClose();
  }

  Widget buildSectionsView(List<Map<String, String>> sections) {
    return SafeArea( // Ensures the ListView is within the safe area of the device
      child: ClipRect(
        clipBehavior: Clip.hardEdge, // Clips anything that overflows the bounds of this widget
        child: ListView.separated(
          padding: EdgeInsets.only(top: 20),
          itemCount: sections.length,
          itemBuilder: (BuildContext context, int index) {
            return ListTile(
              title: Text(
                sections[index]['Title'] ?? '',
                style: TextStyle(
                  overflow: TextOverflow.ellipsis, // Ensures text does not overflow and is instead clipped with an ellipsis
                ),
              ),
              subtitle: Text(
                sections[index]['URL'] ?? '',
                style: TextStyle(
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              shape: RoundedRectangleBorder(
                side: BorderSide(color: Colors.blue, width: 2),
                borderRadius: BorderRadius.circular(5),
              ),
              onTap: () async {
                String? link = sections[index]['URL'];
                if (link != null && link.isNotEmpty) {
                  if (!await launchUrl(Uri.parse(link))) {
                    // Handle the situation when the URL could not be launched.
                    print("Could not launch $link");
                  }
                } else {
                  // Handle the situation when the link is null or empty.
                  print("Link is null or empty");
                }
              },
            );
          },
          separatorBuilder: (context, index) => SizedBox(height: 20),
        ),
      ),
    );
  }

  Widget buildFavoritesList() {
    return ListView.separated(
      itemCount: favCompaniesName.length, // Assuming all lists are of the same length
      itemBuilder: (context, index) {
        return Container(
          padding: EdgeInsets.all(16.0), // Inner padding for the text
          decoration: BoxDecoration(
            border: Border.all(color: Colors.blueAccent, width: 2.0), // Blue border
            borderRadius: BorderRadius.circular(12.0), // Rounded corners
            color: Colors.white, // Background color for the container
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Column for the company name and sentiment
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      favCompaniesName[index], // Company name
                      style: TextStyle(
                        fontWeight: FontWeight.bold, // Bold text style
                        fontSize: 20.0, // Larger font size for company name
                      ),
                    ),
                    SizedBox(height: 8.0), // Space between the company name and sentiment
                    Text(
                      favCompaniesOutcome[index], // Company sentiment
                      style: TextStyle(
                        fontSize: 18.0, // Larger font size for company sentiment
                      ),
                    ),
                  ],
                ),
              ),
              // Column for the confidence score
              Container(
                padding: EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0), // Padding for the score box
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.blueAccent, width: 1.0), // Border for the score box
                  borderRadius: BorderRadius.circular(8.0), // Rounded corners for the score box
                ),
                child: Text(
                  '${favCompaniesConfidence[index]}%', // Confidence score
                  style: TextStyle(
                    fontSize: 18.0, // Font size for confidence score
                    fontWeight: FontWeight.bold, // Bold font style for confidence score
                  ),
                ),
              ),
            ],
          ),
        );
      },
      separatorBuilder: (context, index) {
        return SizedBox(height: 16.0); // Space between the list items
      },
    );
  }




}
