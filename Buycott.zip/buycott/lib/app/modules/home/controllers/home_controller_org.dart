import 'package:get/get.dart';
import 'package:camera/camera.dart';
import 'package:google_ml_kit/google_ml_kit.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class HomeController extends GetxController {
  RxString selectedImagePath = ''.obs;
  RxString extractedBarcode = ''.obs;
  RxBool isCameraInitialized = false.obs;
  RxInt tabIndex = 0.obs;
  late CameraController cameraController;

  @override
  void onInit() {
    super.onInit();
    initializeCamera();
  }

  Future<void> initializeCamera() async {
    final cameras = await availableCameras();
    final firstCamera = cameras.first;

    cameraController = CameraController(firstCamera, ResolutionPreset.medium);
    await cameraController.initialize();
    isCameraInitialized.value = true;
  }

  Future<void> takePhoto() async {
    if (!isCameraInitialized.value) {
      Get.snackbar("Error", "Camera not initialized", backgroundColor: Colors.red);
      return;
    }
    final XFile? photo = await cameraController.takePicture();
    if (photo != null) {
      selectedImagePath.value = photo.path;
      isCameraInitialized.value = false; // Stop camera preview
      // Call your method to recognize text or process the photo
      await recognizedText(selectedImagePath.value);
    }
  }

  Future<void> recognizedText(String pickedImage) async {
    if (pickedImage.isEmpty) {
      Get.snackbar("Error", "Image is not selected", backgroundColor: Colors.red);
    } else {
      extractedBarcode.value = '';
      var barCodeScanner = GoogleMlKit.vision.barcodeScanner();
      final visionImage = InputImage.fromFilePath(pickedImage);

      try {
        var barcodeText = await barCodeScanner.processImage(visionImage);
        for (Barcode barcode in barcodeText) {
          extractedBarcode.value = barcode.displayValue!;
          print('Barcode found: ${barcode.displayValue}');
        }
      } catch (e) {
        Get.snackbar("Error", e.toString(), backgroundColor: Colors.red);
      }
    }
  }

  Future<void> fetchData(String barcodeNumber) async {
    // ...
    // The rest of your fetchData method remains unchanged.
  }

  void changeTabIndex(int index) {
    tabIndex.value = index;
  }

  @override
  void onClose() {
    if (isCameraInitialized.value) {
      cameraController.dispose();
    }
    super.onClose();
  }
}
