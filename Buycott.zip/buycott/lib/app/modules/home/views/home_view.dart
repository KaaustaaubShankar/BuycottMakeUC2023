import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:camera/camera.dart';
import 'package:fl_chart/fl_chart.dart';

import '../controllers/home_controller.dart';

class HomeView extends GetView<HomeController> {
  const HomeView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(() => controller.tabIndex.value == 0 ? _buildCameraView() : _buildOtherTab()),
      bottomNavigationBar: Obx(() => BottomNavigationBar(
        currentIndex: controller.tabIndex.value,
        onTap: controller.changeTabIndex,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.camera),
            label: 'Barcode Lookup',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            label: 'Company Lookup',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: 'Favorites',
          ),
        ],
      )),
    );
  }
  Widget _buildCameraView() {
    return Obx(() {
      if (controller.isCameraInitialized.isTrue) {
        return Column(
          children: [
            Expanded(
              child: CameraPreview(controller.cameraController),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: FloatingActionButton(
                onPressed: controller.takePhoto,
                heroTag: 'camera',
                child: const Icon(Icons.camera_alt),
              ),
            ),
          ],
        );
      } else if (controller.selectedImagePath.value.isNotEmpty) {
        return Column(
          children: [
            Expanded(
              child: Image.file(File(controller.selectedImagePath.value)),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    controller.selectedImagePath.value = '';
                    controller.isCameraInitialized.value = true;
                    controller.dispose();
                    controller.initializeCamera();
                  },
                  child: const Text('Retry'),
                  style: ElevatedButton.styleFrom(
                    primary: Colors.redAccent,
                  ),
                ),
                ElevatedButton(
                  onPressed: () async {
                    await controller.recognizedText(controller.selectedImagePath.value);
                    controller.fetchData(controller.extractedBarcode.value);

                    if (controller.extractedBarcode.isNotEmpty) {
                      Get.snackbar(
                        'Success',
                        'Barcode: ${controller.extractedBarcode.value}',
                        backgroundColor: Colors.greenAccent,
                      );

                      // Wait for the Snackbar to be shown before switching tab
                      Future.delayed(const Duration(seconds: 2), () {
                        controller.changeTabIndex(1);
                      });
                    } else {
                      Get.snackbar(
                        'Error',
                        'No barcode found. Try again.',
                        backgroundColor: Colors.redAccent,
                      );
                    }
                  },
                  child: const Text('Ok'),
                  style: ElevatedButton.styleFrom(
                    primary: Colors.greenAccent,
                  ),
                ),
              ],
            ),
          ],
        );
      } else {
        return const Center(child: CircularProgressIndicator());
      }
    });
  }

  Widget _buildOtherTab() {

    switch (controller.tabIndex.value) {
      case 1:
      // Company Lookup content\
// Company Lookup content

        bool isFavorite = false;
        Icon favoriteIcon = Icon(Icons.favorite_border,size: 32);
        return Scaffold(
          body: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisAlignment: MainAxisAlignment.start, // Align items to the start of the main axis.
              children: [
                SizedBox(height: 32), // Space at the top of the Scaffold.
                // Container for Company Name and Barcode Number
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.blue, width: 5),
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                  ),
                  padding: const EdgeInsets.only(top: 15.0, bottom: 10.0),
                  child: Row(
                    children:[
                      SizedBox(width:40),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Company Name
                          Text(
                            controller.companyName.toString(),
                            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                            textAlign: TextAlign.center,
                          ),
                          SizedBox(height: 10), // Space between company name and barcode.
                          // Barcode Number
                          Text(
                            controller.extractedBarcode.value,
                            style: TextStyle(fontSize: 16),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                      Expanded(
                        child:IconButton(
                          icon: Obx(() => Icon(controller.favoriteIcon.value)),
                          color: Colors.red, // Color for the heart icon.
                          onPressed: () {
                            if (!isFavorite){
                              controller.favCompaniesName.add(controller.companyName.toString());
                              controller.favCompaniesOutcome.add(controller.sentiment.toString());
                              controller.favCompaniesConfidence.add(( controller.confidence.round() - 1).toString());
                              controller.favoriteIcon.value = Icons.favorite;
                              isFavorite = true;
                            }else{
                              // favCompanies.removeLast();
                              controller.favCompaniesName.removeWhere((item) => item == controller.companyName.toString());
                              controller.favCompaniesOutcome.removeWhere((item) => item == controller.sentiment.toString());
                              controller.favCompaniesConfidence.removeWhere((item) => item == controller.confidence.toString());
                              controller.favoriteIcon.value = Icons.favorite_border;
                              isFavorite = false;
                            }
                            print(controller.favCompaniesName);


                            // TODO: Implement the functionality for the heart button press.
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 16), // Reduced space between the container and the pie chart row.
                // Row for Pie Chart and Confidence Level
                Row(
                  mainAxisAlignment: MainAxisAlignment.start, // Align items to the start of the row.
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Flexible(
                    // Pie Chart Placeholder
                    child: AspectRatio(
                        aspectRatio: 1,
                  child: PieChart(
                      PieChartData(
                        centerSpaceRadius: 0, // Set the center space radius to 0
                        startDegreeOffset: 0,
                        sections: [
                          PieChartSectionData(
                            value: controller.percentageP.toDouble() == 0 ? 1: controller.percentageP.toDouble(),
                            color: (controller.percentageI.toDouble() == 100 || controller.percentageN.toDouble() == 100 || controller.percentageN.toDouble() == 100)? Colors.grey:Colors.blue,
                            radius: 75, // Set the radius to cover the entire chart,
                          ),
                          PieChartSectionData(
                            value: controller.percentageI.toDouble() == 0 ? 1: controller.percentageI.toDouble(),
                            color: (controller.percentageI.toDouble() == 100 || controller.percentageN.toDouble() == 100 || controller.percentageN.toDouble() == 100)? Colors.grey: Colors.orange,
                            radius: 75, // Set the radius to cover the entire chart,
                          ),
                          PieChartSectionData(
                            value: controller.percentageN.toDouble() == 0 ? 1: controller.percentageN.toDouble(),
                            color: Colors.grey,
                            radius: 75, // Set the radius to cover the entire chart
                          ),
                        ],
                      ),
                    ),
                    )
                    ),
                    SizedBox(width: 16), // Spacing between the pie chart and text.
                    // Confidence Level Text
                    Flexible(

                      child: Text(
                        controller.confidence.round().toString() + " " + controller.sentiment.toString(),
                        style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),
                        maxLines: 1, // Prevent text from wrapping to a new line
                        overflow: TextOverflow.ellipsis, // Show ellipsis if text is too long
                        textAlign: TextAlign.center,

                      ),
                    ),

                  ],
                ),
                Expanded(
                  child:controller.buildSectionsView(controller.titlesAndUrls),

                ),
                // Add SizedBox here if you want more space between the pie chart row and news article.
                // Rest of your code for other elements...
              ],
            ),
          ),
        );



      case 2:
      // Favorites content
        return controller.buildFavoritesList();
      default:
        return Container(); // This should never be happening
    }
  }
}