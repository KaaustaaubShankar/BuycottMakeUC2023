import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:camera/camera.dart';

import '../controllers/home_controller.dart';

class HomeView extends GetView<HomeController> {
  const HomeView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(() => controller.tabIndex.value == 0 ? _buildCameraView() : _buildOtherTab()),
      bottomNavigationBar: Obx(() => BottomNavigationBar(
        currentIndex: controller.tabIndex.value,
        onTap: controller.changeTabIndex,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.camera),
            label: 'Barcode Lookup',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            label: 'Company Lookup',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: 'Favorites',
          ),
        ],
      )),
    );
  }

  Widget _buildCameraView() {
    return Obx(() {
      if (controller.isCameraInitialized.isTrue) {
        return Column(
          children: [
            Expanded(
              child: CameraPreview(controller.cameraController),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: FloatingActionButton(
                onPressed: controller.takePhoto,
                heroTag: 'camera',
                child: const Icon(Icons.camera_alt),
              ),
            ),
          ],
        );
      } else if (controller.selectedImagePath.value.isNotEmpty) {
        return Column(
          children: [
            Expanded(
              child: Image.file(File(controller.selectedImagePath.value)),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    controller.selectedImagePath.value = '';
                    controller.isCameraInitialized.value = true;
                    controller.initializeCamera();
                  },
                  child: const Text('Retry'),
                  style: ElevatedButton.styleFrom(
                    primary: Colors.redAccent,
                  ),
                ),
                ElevatedButton(
                  onPressed: () async {
                    await controller.recognizedText(controller.selectedImagePath.value);
                    if (controller.extractedBarcode.isNotEmpty) {
                      Get.snackbar(
                        'Success',
                        'Barcode: ${controller.extractedBarcode.value}',
                        backgroundColor: Colors.greenAccent,
                      );
                      // Wait for the Snackbar to be shown before switching tab
                      Future.delayed(const Duration(seconds: 2), () {
                        controller.changeTabIndex(1);
                      });
                    } else {
                      Get.snackbar(
                        'Error',
                        'No barcode found. Try again.',
                        backgroundColor: Colors.redAccent,
                      );
                    }
                  },
                  child: const Text('Ok'),
                  style: ElevatedButton.styleFrom(
                    primary: Colors.greenAccent,
                  ),
                ),
              ],
            ),
          ],
        );
      } else {
        return const Center(child: CircularProgressIndicator());
      }
    });
  }

  Widget _buildOtherTab() {
    switch (controller.tabIndex.value) {
      case 1:
      // Company Lookup content
        return Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Obx(() {
                  return TextField(
                    controller: TextEditingController(text: controller.extractedBarcode.value)
                      ..selection = TextSelection.collapsed(offset: controller.extractedBarcode.value.length),
                    decoration: InputDecoration(
                      labelText: 'Scanned Barcode',
                      border: OutlineInputBorder(),
                      suffixIcon: controller.extractedBarcode.value.isNotEmpty
                          ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          controller.extractedBarcode.value = '';
                          controller.changeTabIndex(0); // Go back to camera tab if clear is pressed
                        },
                      )
                          : null,
                    ),
                    readOnly: true,
                  );
                }),
              ),
              // Additional UI or functionality for Company Lookup can be added here
            ],
          ),
        );
      case 2:
      // Favorites content
        return Center(
          child: Text('Favorites content goes here'),
        );
      default:
        return Container(); // This should never be happening
    }
  }
}
