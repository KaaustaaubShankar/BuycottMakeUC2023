'''
import 'dart:io';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../controllers/home_controller.dart';

class HomeView extends GetView<HomeController> {
  const HomeView({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('BarCode scanner app'),
        centerTitle: true,
      ),
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Image box container
              Container(
                height: 220,
                margin: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: SingleChildScrollView(
                  child: Obx(() {
                    if (controller.selectedImagePath.value == '') {
                      return const Center(
                        child: Text("Select an image from Gallery / camera"),
                      );
                    } else {
                      return Image.file(
                        File(controller.selectedImagePath.value),
                        width: Get.width,
                        height: 300,
                      );
                    }
                  }),
                ),
              ),

              // Button row
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        controller.getImage(ImageSource.gallery);
                      },
                      child: const Text("Pick Image"),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        controller.getImage(ImageSource.camera);
                      },
                      child: const Text("Take Picture"),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        controller.recognizedText(controller.selectedImagePath.value);
                      },
                      child: const Text("Read Code"),
                    ),

                  ],
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  controller.fetchData(controller.extractedBarcode.value); // Call the fetchData method to update the value
                },
                child: const Text("Fetch Data from URL"),
              ),

              // Text box ScrollView
              SingleChildScrollView(
                child: Container(
                  height: 190,
                  margin: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Obx(() {
                    if (controller.extractedBarcode.value.isEmpty) {
                      return const Center(child: Text("Barcode Not Found"));
                    } else {
                      return Center(child: Text(controller.extractedBarcode.value));
                    }
                  }),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
'''