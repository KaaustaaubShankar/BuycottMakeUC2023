package com.example.buycott

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
