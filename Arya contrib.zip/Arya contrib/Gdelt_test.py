import requests
import csv

# Function to get sentiment queries from GDELT
def get_sentiment_queries(query, tone, max_results, sort_order):
    # Construct the API URL with the query, tone filter, sort order, source language, and format as JSON
    api_url = f"https://api.gdeltproject.org/api/v2/doc/doc?query={query} sourcelang:english&tone:{tone}&maxrecords={max_results}&sort={sort_order}&format=json"
    
    # Make the API request
    response = requests.get(api_url)
    
    # Check if the request was successful
    if response.status_code == 200:
        return response.json()  # Parse the response as JSON
    else:
        print(f"Error: {response.status_code}")
        return None

# Function to save articles to CSV
def save_to_csv(articles, filename):
    if not articles:
        print(f"No articles to save for {filename}.")
        return

    with open(filename, 'w', newline='', encoding='utf-8') as output_file:
        # Assuming articles is a list of dictionaries
        keys = articles[0].keys()
        dict_writer = csv.DictWriter(output_file, fieldnames=keys)
        dict_writer.writeheader()
        dict_writer.writerows(articles)

# Define the query and parameters
query = 'starbucks AND (Palestine OR Israel)'
max_results = 150

# Get negative sentiment queries sorted by HybridRelMag and tone in descending order
negative_sentiment_data = get_sentiment_queries(query, '<0', max_results, 'tonedesc,HybridRelMag')
if negative_sentiment_data and 'articles' in negative_sentiment_data:
    save_to_csv(negative_sentiment_data['articles'], 'negative_sentiment_articles.csv')
    print("Negative sentiment articles saved to negative_sentiment_articles.csv")

# Get positive sentiment queries sorted by HybridRelMag and tone in ascending order
positive_sentiment_data = get_sentiment_queries(query, '>0', max_results, 'toneasc,HybridRelMag')
if positive_sentiment_data and 'articles' in positive_sentiment_data:
    save_to_csv(positive_sentiment_data['articles'], 'positive_sentiment_articles.csv')
    print("Positive sentiment articles saved to positive_sentiment_articles.csv")
