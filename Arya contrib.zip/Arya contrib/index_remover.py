import pandas as pd

# Read the CSV file
df = pd.read_csv('tagged_neg.csv')

# Remove the index column
df = df.drop(columns=['Unnamed: 0'])

# Save the modified DataFrame back to the CSV file
df.to_csv(r'C:\Users\Hackathon\Desktop\tagged_neg.csv', index=False)
